Coin Catch Android प्रोजेक्ट

यह Android Studio में खोलने योग्य शुरुआती WebView wrapper प्रोजेक्ट है।
यह अभी signed APK/AAB नहीं है और Android Studio/SDK से build व परीक्षण बाकी है।

Build करने के लिए:
1. Android Studio स्थापित करें.
2. इस ZIP को Extract करें.
3 Android Studio में Open चुनकर CoinCatch फ़ोल्डर खोलें.
4 Gradle Sync पूरा होने दें.
5 Run से Android emulator या वास्तविक फोन पर परीक्षण करें.
6 Play Store AAB बनाने से पहले ऐप का परीक्षण, privacy disclosures और Google Play की सभी शर्तें पूरी करें.

इस शुरुआती प्रोजेक्ट में इंटरनेट permission नहीं है; गेम offline चलता है.
Monetization, payment, ads, login या cash rewards शामिल नहीं हैं.
