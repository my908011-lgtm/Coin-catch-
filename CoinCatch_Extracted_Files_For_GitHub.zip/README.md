# Coin Catch (first game version)

This package uses the first standalone Coin Catch HTML game as the Android WebView game asset and includes a GitHub Actions APK build workflow.


## Upload on mobile
1. Extract this ZIP (don't upload the ZIP itself as the repository contents).
2. Create a GitHub repository.
3. Upload all extracted files and folders to the repository root, including `.github/workflows/build-apk.yml`.
4. Open **Actions** → **Build Coin Catch APK** → **Run workflow**.
5. If the build succeeds, download the APK from the run's **Artifacts** section.

Build is not verified; this project has not been compiled or device-tested in this environment.
